package org.avmedia.gshockGoogleSync.ui.settings

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.text.SimpleDateFormat
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.avmedia.gshockGoogleSync.data.repository.GShockRepository
import org.avmedia.gshockGoogleSync.ActionContainer
import org.avmedia.gshockGoogleSync.utils.LocalDataStorage
import org.avmedia.gshockapi.model.Settings
import org.json.JSONObject
import org.avmedia.gshockGoogleSync.ui.common.AppSnackbar
import org.avmedia.gshockGoogleSync.ui.common.IWatchFeatureManager
import org.avmedia.gshockapi.EventAction
import org.avmedia.gshockapi.ProgressEvents

abstract class Setting(val name: String) {
    open suspend fun save() {} // Default empty implementation
}

data class SettingsState(
    val settings: List<Setting> = emptyList(),
    val settingsMap: Map<Class<out Setting>, Setting> = emptyMap(),
)

@HiltViewModel
class SettingsViewModel
@Inject
constructor(
    private val api: GShockRepository,
    private val watchFeatureManager: IWatchFeatureManager,
    @param:ApplicationContext private val appContext: Context,
    private val actionContainer: ActionContainer,
) : ViewModel() {

    fun onSettingUpdated(setting: Setting) {
        updateSetting(setting)
    }

    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    init {
        initializeSettings()
        setupEventSubscription()
    }

    private fun setupEventSubscription() {
        ProgressEvents.runEventActions(
            this.javaClass.canonicalName ?: "SettingsViewModel",
            arrayOf(
            EventAction("DeviceName") {
                initializeSettings()
            },
            EventAction("ConnectionSetupComplete") {
                initializeSettings()
            },
            EventAction("SettingsUpdated") {
                val payload = ProgressEvents.getPayload("SettingsUpdated") as? Settings
                initializeSettings(payload)
            }
        ))
    }

    private fun initializeSettings(freshSettings: Settings? = null) {
        val newSettings =
            arrayListOf(
                Locale(),
                OperationSound(),
                Light(),
                PowerSavingMode(),
                Font(),
                TimeAdjustment(appContext),
            )
        updateSettingsAndMap(filter(newSettings))

        viewModelScope.launch(Dispatchers.Default) {
            val settings = freshSettings ?: api.getSettings()
            val settingsJson = Gson().toJsonTree(settings).asJsonObject
            val settingStr = Gson().toJson(settingsJson)
            updateSettingsAndMap(fromJson(settingStr))
        }
    }

    private fun updateSettingsAndMap(newSettings: ArrayList<Setting>) {
        val newMap = newSettings.associateBy { it::class.java }
        _state.update { it.copy(settings = newSettings, settingsMap = newMap) }
    }

    @Suppress("UNCHECKED_CAST")
    fun <T : Setting> getSetting(type: Class<T>): T {
        return state.value.settingsMap[type] as T
    }

    private fun updateSetting(updatedSetting: Setting) {
        val currentList = state.value.settings.toMutableList()
        val index = currentList.indexOfFirst { it::class == updatedSetting::class }
        if (index != -1) {
            currentList[index] = updatedSetting
            val newMap = state.value.settingsMap.toMutableMap()
            newMap[updatedSetting::class.java] = updatedSetting
            _state.update { it.copy(settings = currentList, settingsMap = newMap) }
            viewModelScope.launch { updatedSetting.save() }
        }
    }

    data class Locale(
        var timeFormat: TimeFormat = TimeFormat.TWELVE_HOURS,
        var dateFormat: DateFormat = DateFormat.MONTH_DAY,
        var dayOfWeekLanguage: DayOfWeekLanguage = DayOfWeekLanguage.ENGLISH,
    ) : Setting("Locale") {
        enum class TimeFormat(val value: String) {
            TWELVE_HOURS("12h"),
            TWENTY_FOUR_HOURS("24h"),
        }

        enum class DateFormat(val value: String) {
            MONTH_DAY("MM:DD"),
            DAY_MONTH("DD:MM"),
        }

        enum class DayOfWeekLanguage(val nativeName: String, val englishName: String) {
            ENGLISH("English", "English"),
            SPANISH("Español", "Spanish"),
            FRENCH("Français", "French"),
            GERMAN("Deutsch", "German"),
            ITALIAN("Italiano", "Italian"),
            RUSSIAN("Русский", "Russian")
        }
    }

    data class OperationSound(var sound: Boolean = true, var vibrate: Boolean = false) :
        Setting("Button Sound")

    data class Light(
        var autoLight: Boolean = false,
        var duration: LightDuration = LightDuration.TWO_SECONDS,
    ) : Setting("Light") {
        enum class LightDuration(val value: String) {
            TWO_SECONDS("2s"),
            FOUR_SECONDS("4s")
        }
    }

    data class PowerSavingMode(var powerSavingMode: Boolean = false) : Setting("Power Saving Mode")

    data class TimeAdjustment(
        val appContext: Context,
        var timeAdjustment: Boolean = true,
        var adjustmentTimeMinutes: Int = 0,
        var timeAdjustmentNotifications: Boolean =
            LocalDataStorage.getTimeAdjustmentNotification(appContext),
        var fineAdjustment: Int = LocalDataStorage.getFineTimeAdjustment(appContext),
    ) : Setting("Time Adjustment") {
        override suspend fun save() {
            LocalDataStorage.setTimeAdjustmentNotification(appContext, timeAdjustmentNotifications)
            LocalDataStorage.setFineTimeAdjustment(appContext, fineAdjustment)
        }
    }

    data class Font(var font: FontType = FontType.STANDARD) : Setting("Font") {
        enum class FontType(val value: String) {
            STANDARD("Standard"),
            CLASSIC("Classic")
        }
    }

    private fun filter(settings: ArrayList<Setting>): ArrayList<Setting> {
        return settings.filter { setting ->
            when (setting) {
                is PowerSavingMode -> watchFeatureManager.isFeatureSupported("settings.power_saving")
                is Font -> watchFeatureManager.isFeatureSupported("settings.multiple_fonts")
                else -> true
            }
        } as
                ArrayList<Setting>
    }

    @Synchronized
    fun fromJson(jsonStr: String): ArrayList<Setting> {
        val updatedObjects = mutableSetOf<Setting>()
        val jsonObj = JSONObject(jsonStr)
        val jsonObjKeys = jsonObj.keys()

        while (jsonObjKeys.hasNext()) {
            val key: String = jsonObjKeys.next()
            val value = jsonObj[key]

            when (key) {
                "powerSavingMode" -> handlePowerSavingMode(value, updatedObjects)
                "timeAdjustment" -> handleTimeAdjustment(value, updatedObjects)
                "adjustmentTimeMinutes" -> handleAdjustmentTimeMinutes(value, updatedObjects)
                "buttonTone" -> handleButtonTone(value, updatedObjects)
                "keyVibration" -> handleButtonVibration(value, updatedObjects)
                "autoLight" -> handleAutoLight(value, updatedObjects)
                "lightDuration" -> handleLightDuration(value, updatedObjects)
                "timeFormat" -> handleTimeFormat(value, updatedObjects)
                "dateFormat" -> handleDateFormat(value, updatedObjects)
                "language" -> handleLanguage(value, updatedObjects)
                "font" -> handleFont(value, updatedObjects)
            }
        }

        return ArrayList(updatedObjects)
    }

    private fun handlePowerSavingMode(value: Any, updatedObjects: MutableSet<Setting>) {
        if (watchFeatureManager.isFeatureSupported("settings.power_saving")) {
            val setting = state.value.settingsMap[PowerSavingMode::class.java] as PowerSavingMode
            setting.powerSavingMode = value == true
            updatedObjects.add(setting)
        }
    }

    private fun handleTimeAdjustment(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[TimeAdjustment::class.java] as TimeAdjustment
        setting.timeAdjustment = value == true
        updatedObjects.add(setting)
    }

    private fun handleAdjustmentTimeMinutes(value: Any, updatedObjects: MutableSet<Setting>) {
        if (!watchFeatureManager.isFeatureSupported("time_adjustment.always_connected")) {
            val setting = state.value.settingsMap[TimeAdjustment::class.java] as TimeAdjustment
            setting.adjustmentTimeMinutes = value as Int
            updatedObjects.add(setting)
        }
    }

    private fun handleButtonTone(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[OperationSound::class.java] as OperationSound
        setting.sound = value == true
        updatedObjects.add(setting)
    }

    private fun handleButtonVibration(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[OperationSound::class.java] as OperationSound
        setting.vibrate = value == true
        updatedObjects.add(setting)
    }

    private fun handleAutoLight(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[Light::class.java] as Light
        setting.autoLight = value == true
        updatedObjects.add(setting)
    }

    private fun handleLightDuration(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[Light::class.java] as Light
        setting.duration =
            if (value == Light.LightDuration.TWO_SECONDS.value) {
                Light.LightDuration.TWO_SECONDS
            } else {
                Light.LightDuration.FOUR_SECONDS
            }
        updatedObjects.add(setting)
    }

    private fun handleTimeFormat(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[Locale::class.java] as Locale
        setting.timeFormat =
            if (value == Locale.TimeFormat.TWELVE_HOURS.value) {
                Locale.TimeFormat.TWELVE_HOURS
            } else {
                Locale.TimeFormat.TWENTY_FOUR_HOURS
            }
        updatedObjects.add(setting)
    }

    private fun handleDateFormat(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[Locale::class.java] as Locale
        setting.dateFormat =
            if (value == Locale.DateFormat.MONTH_DAY.value) {
                Locale.DateFormat.MONTH_DAY
            } else {
                Locale.DateFormat.DAY_MONTH
            }
        updatedObjects.add(setting)
    }

    private fun handleLanguage(value: Any, updatedObjects: MutableSet<Setting>) {
        val setting = state.value.settingsMap[Locale::class.java] as Locale
        setting.dayOfWeekLanguage =
            when (value) {
                Locale.DayOfWeekLanguage.ENGLISH.englishName -> Locale.DayOfWeekLanguage.ENGLISH
                Locale.DayOfWeekLanguage.SPANISH.englishName -> Locale.DayOfWeekLanguage.SPANISH
                Locale.DayOfWeekLanguage.FRENCH.englishName -> Locale.DayOfWeekLanguage.FRENCH
                Locale.DayOfWeekLanguage.GERMAN.englishName -> Locale.DayOfWeekLanguage.GERMAN
                Locale.DayOfWeekLanguage.ITALIAN.englishName -> Locale.DayOfWeekLanguage.ITALIAN
                Locale.DayOfWeekLanguage.RUSSIAN.englishName -> Locale.DayOfWeekLanguage.RUSSIAN
                else -> setting.dayOfWeekLanguage
            }
        updatedObjects.add(setting)
    }

    private fun handleFont(value: Any, updatedObjects: MutableSet<Setting>) {
        if (watchFeatureManager.isFeatureSupported("settings.multiple_fonts")) {
            val setting = state.value.settingsMap[Font::class.java] as Font
            setting.font =
                if (value == Font.FontType.CLASSIC.value) {
                    Font.FontType.CLASSIC
                } else {
                    Font.FontType.STANDARD
                }
            updatedObjects.add(setting)
        }
    }

    @SuppressLint("SimpleDateFormat")
    private suspend fun getSmartDefaults(): ArrayList<Setting> {
        val smartSettings = arrayListOf<Setting>()
        val currentLocale = java.util.Locale.getDefault()

        val language =
            when (currentLocale.language) {
                "en" -> Locale.DayOfWeekLanguage.ENGLISH
                "es" -> Locale.DayOfWeekLanguage.SPANISH
                "fr" -> Locale.DayOfWeekLanguage.FRENCH
                "de" -> Locale.DayOfWeekLanguage.GERMAN
                "it" -> Locale.DayOfWeekLanguage.ITALIAN
                "ru" -> Locale.DayOfWeekLanguage.RUSSIAN
                else -> Locale.DayOfWeekLanguage.ENGLISH
            }

        val dateTimePattern = SimpleDateFormat().toPattern()
        val datePattern = dateTimePattern.split(" ")[0]
        val timePattern = dateTimePattern.split(" ")[1]

        val dateFormat =
            if (datePattern.lowercase().startsWith("d")) {
                Locale.DateFormat.DAY_MONTH
            } else {
                Locale.DateFormat.MONTH_DAY
            }
        val timeFormat =
            if (timePattern[0] == 'h') {
                Locale.TimeFormat.TWELVE_HOURS
            } else {
                Locale.TimeFormat.TWENTY_FOUR_HOURS
            }
        val locale =
            Locale(
                timeFormat = timeFormat,
                dateFormat = dateFormat,
                dayOfWeekLanguage = language
            )
        smartSettings.add(locale)

        val notificationManager =
            appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val buttonTone =
            notificationManager.currentInterruptionFilter ==
                    NotificationManager.INTERRUPTION_FILTER_ALL
        val operationSound = OperationSound(buttonTone)
        smartSettings.add(operationSound)

        val autoLight = false
        val light = Light(autoLight, Light.LightDuration.TWO_SECONDS)
        smartSettings.add(light)

        if (watchFeatureManager.isFeatureSupported("settings.power_saving")) {
            val batteryLevel = api.getBatteryLevel()
            val currentPowerSavingMode: PowerSavingMode =
                state.value.settingsMap[PowerSavingMode::class.java] as PowerSavingMode

            val enablePowerSetting = (batteryLevel <= 15) || currentPowerSavingMode.powerSavingMode
            val powerSavings = PowerSavingMode(enablePowerSetting)
            smartSettings.add(powerSavings)
        }
        if (watchFeatureManager.isFeatureSupported("settings.multiple_fonts")) {
            val currentFontName = api.getSettings().font
            val newFontName = if (currentFontName == "Classic") Font.FontType.CLASSIC else Font.FontType.STANDARD
            val font = Font(newFontName)
            smartSettings.add(font)
        }

        val notifyMe = LocalDataStorage.getTimeAdjustmentNotification(appContext)
        val timeAdjustment =
            TimeAdjustment(
                appContext = appContext,
                timeAdjustment = true,
                adjustmentTimeMinutes = 30,
                timeAdjustmentNotifications = notifyMe,
                fineAdjustment = 0
            )
        smartSettings.add(timeAdjustment)

        return smartSettings
    }

    fun setSmartDefaults() {
        viewModelScope.launch {
            runCatching {
                updateSettingsAndMap(getSmartDefaults())
                state.value.settings.forEach { it.save() }
            }
                .onFailure { e -> AppSnackbar(e.message ?: "Error") }
        }
    }

    fun sendToWatch() {
        val settings = Settings()

        val localeSetting: Locale = state.value.settingsMap[Locale::class.java] as Locale
        settings.language = localeSetting.dayOfWeekLanguage.englishName
        settings.timeFormat = localeSetting.timeFormat.value
        settings.dateFormat = localeSetting.dateFormat.value

        val lightSetting: Light = state.value.settingsMap[Light::class.java] as Light
        settings.autoLight = lightSetting.autoLight
        settings.lightDuration = lightSetting.duration.value

        if (watchFeatureManager.isFeatureSupported("settings.power_saving")) {
            val powerSavingMode: PowerSavingMode =
                state.value.settingsMap[PowerSavingMode::class.java] as PowerSavingMode
            settings.powerSavingMode = powerSavingMode.powerSavingMode
        }

        val buttonTone: OperationSound =
            state.value.settingsMap[OperationSound::class.java] as OperationSound
        settings.buttonTone = buttonTone.sound
        settings.keyVibration = buttonTone.vibrate

        val timeAdjustment: TimeAdjustment =
            state.value.settingsMap[TimeAdjustment::class.java] as TimeAdjustment
        settings.timeAdjustment = timeAdjustment.timeAdjustment
        settings.adjustmentTimeMinutes = timeAdjustment.adjustmentTimeMinutes

        if (watchFeatureManager.isFeatureSupported("settings.multiple_fonts")) {
            val fontSetting: Font = state.value.settingsMap[Font::class.java] as Font
            settings.font = fontSetting.font.value
        }

        val settingsAction =
            actionContainer.getAction(ActionContainer.SetSettingsAction::class.java)
        if (!settingsAction.shouldRun(ActionContainer.RunEnvironment.DIRECT_INVOCATION)) {
            return
        }

        viewModelScope.launch {
            settingsAction.runWithSettings(appContext, settings)
        }
    }
}
