package org.avmedia.gshockGoogleSync

import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.provider.Settings
import android.app.AlertDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.avmedia.gshockGoogleSync.data.repository.GShockRepository
import org.avmedia.gshockGoogleSync.services.NotificationMonitorService
import org.avmedia.gshockGoogleSync.utils.ActivityProvider
import org.avmedia.gshockGoogleSync.utils.Utils
import org.avmedia.gshockapi.AppNotification
import org.avmedia.gshockapi.EventAction
import org.avmedia.gshockapi.ProgressEvents
import timber.log.Timber

class MainEventHandler(
    private val context: GShockApplication,
    private val repository: GShockRepository,
    private val screenManager: IScreenManager
) {
    fun setupEventSubscription() {
        val eventActions = arrayOf(
            EventAction("ConnectionSetupComplete") {},
            EventAction("WatchInitializationCompleted") { handleWatchInitialization() },
            EventAction("ConnectionFailed") { handleConnectionFailure() },
            EventAction("Error") { handleError() },
            EventAction("WaitForConnection") { handleWaitForConnection() },
            EventAction("Disconnect") { handleDisconnect() },
            EventAction("HomeTimeUpdated") {},
            EventAction("RunActions") { handleRunAction() },
            EventAction("AppNotification") { handleAppNotification() },
            EventAction("LocationServicesDisabled") { handleLocationServicesDisabled() }
        )

        ProgressEvents.runEventActions(Utils.AppHashCode(), eventActions)
    }

    private fun handleWatchInitialization() {
        Timber.i("Received WatchInitializationCompleted")
        if (repository.supportsAppNotifications()) {
            NotificationMonitorService.startService(context)
        }
        if (repository.isNormalButtonPressed()) {
            Timber.i("Normal watch connection; opening Time navigation")
            screenManager.showMainNavigation()
        } else {
            Timber.i("Special watch button connection; resolving content selector")
            screenManager.showContentSelector(repository)
        }
    }

    private fun handleAppNotification() {
        if (repository.supportsAppNotifications()) {
            val appNotification = ProgressEvents.getPayload("AppNotification") as AppNotification?
            if (appNotification != null) {
                repository.sendAppNotification(appNotification)
            }
        }
    }

    private fun handleConnectionFailure() {
        Timber.e("Failed to connect to the watch")
    }

    private fun handleRunAction() {
        screenManager.showRunActionsScreen()

        CoroutineScope(Dispatchers.Main).launch {
            delay(3000)
            screenManager.showContentSelector(repository)
        }
    }

    private fun handleError() {
        val payload = ProgressEvents.getPayload("Error") as String?
        val message = payload
            ?: context.getString(
                R.string.apierror_ensure_the_official_g_shock_app_is_not_running
            )
        Timber.e("API Error event. payload=${payload ?: "<none, using default message>"}")

        repository.disconnect()
        screenManager.showError(message)
        screenManager.showPreConnectionScreen()
    }

    private fun handleDisconnect() {
        ProgressEvents.getPayload("Disconnect")?.let { device ->
            repository.teardownConnection(device as BluetoothDevice)
        }
        Timber.i("Watch disconnected; returning to pre-connection screen")
        screenManager.showInitialScreen()
    }

    private fun handleWaitForConnection() {
        CoroutineScope(Dispatchers.Default).launch {
            context.companionDeviceCoordinator.checkPairedDevicesOrNotify()
        }
    }

    private fun handleLocationServicesDisabled() {
        CoroutineScope(Dispatchers.Main).launch {
            val activity = ActivityProvider.getCurrentActivity() ?: run {
                Timber.e("No activity available to show location services dialog")
                return@launch
            }

            AlertDialog.Builder(activity)
                .setTitle("Location Services Required")
                .setMessage("Android requires Location Services to be enabled for Bluetooth scanning. This app does not use your location — it is an Android system requirement.")
                .setPositiveButton("Open Settings") { _, _ ->
                    activity.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .setCancelable(false)
                .show()
        }
    }

}
